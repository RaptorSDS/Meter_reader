Meter Reader 

read all OBIS

no UAC need 

Windows 10/11 (tested) with HICHI USB Adapter (should work with all USB to Serial "Optical" adapter )

EXE version compile tkinter version (super small 10MB)

use smllib from  spaceman_spiff  on PIP  (  GNU General Public License v3 or later (GPLv3+) )




table highlight for most used value for electricity meter , 
1.8.0
2.8.0
c.1.0
0.2.0


debug view of communication (hex) 
read OBIS Value scale and unit



make windows exe by auto_py_to_exe

1. install phyton 3.12 ( windows store)
2. cmd type pip install pyqt6 pyserial smllib auto-py-to-exe  (or pyqt5 , tkinter already in phyton3.12)
3. cmd type python -m auto_py_to_exe
4. use the webinterface to spec where the py script is
5. compile
6. use the result exe 

